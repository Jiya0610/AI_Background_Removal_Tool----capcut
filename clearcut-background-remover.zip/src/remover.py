"""AI foreground segmentation and alpha-mask refinement."""

from __future__ import annotations

import cv2
import numpy as np
from PIL import Image

from src.image_utils import prepare_for_inference


class RemovalError(RuntimeError):
    """Raised when foreground segmentation fails or returns invalid data."""


def generate_foreground_mask(image: Image.Image, session) -> Image.Image:
    """Infer an L-mode foreground mask at the source image's full dimensions."""
    source = image.convert("RGB")
    model_input = prepare_for_inference(source)
    try:
        from rembg import remove

        segmented = remove(model_input, session=session, only_mask=False, post_process_mask=True)
        if isinstance(segmented, Image.Image):
            mask = segmented.convert("RGBA").getchannel("A")
        else:
            mask = Image.fromarray(np.asarray(segmented).astype(np.uint8)).convert("RGBA").getchannel("A")
    except Exception as exc:
        raise RemovalError(f"Foreground segmentation failed: {exc}") from exc

    if mask.size != source.size:
        mask = mask.resize(source.size, Image.Resampling.LANCZOS)
    return mask.convert("L")


def apply_foreground_mask(image: Image.Image, mask: Image.Image, edge_softness: float = 0.7) -> Image.Image:
    """Apply a reusable mask, with adjustable low-radius Gaussian edge smoothing."""
    alpha = np.asarray(mask.convert("L"), dtype=np.uint8)
    if edge_softness > 0:
        alpha = cv2.GaussianBlur(alpha, (0, 0), sigmaX=float(edge_softness), sigmaY=float(edge_softness))
    rgba = image.convert("RGB").convert("RGBA")
    rgba.putalpha(Image.fromarray(alpha, mode="L"))
    return rgba
