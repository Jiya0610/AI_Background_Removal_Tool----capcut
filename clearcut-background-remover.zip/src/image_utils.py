"""Image input validation, preprocessing, and background compositing."""

from __future__ import annotations

import io

import cv2
import numpy as np
from PIL import Image, ImageOps, UnidentifiedImageError

MAX_UPLOAD_BYTES = 20 * 1024 * 1024
MAX_SIDE = 12_000
MAX_PIXELS = 40_000_000
INFERENCE_MAX_SIDE = 2_000
ALLOWED_FORMATS = {"JPEG", "PNG"}


class ImageValidationError(ValueError):
    """Raised when an uploaded image violates an input constraint."""


def open_uploaded_image(uploaded, *, allow_large: bool = True) -> Image.Image:
    """Decode and validate an uploaded JPG/PNG, returning an RGB image."""
    data = uploaded.getvalue()
    if not data:
        raise ImageValidationError("The uploaded file is empty.")
    if len(data) > MAX_UPLOAD_BYTES:
        raise ImageValidationError("The file is larger than the 20 MB upload limit.")
    try:
        with Image.open(io.BytesIO(data)) as probe:
            image_format = probe.format
            width, height = probe.size
            if image_format not in ALLOWED_FORMATS:
                raise ImageValidationError("Unsupported image format. Please upload a JPG or PNG.")
            if width < 1 or height < 1 or width > MAX_SIDE or height > MAX_SIDE:
                raise ImageValidationError(f"Image dimensions must be no larger than {MAX_SIDE:,} × {MAX_SIDE:,} pixels.")
            if width * height > MAX_PIXELS:
                raise ImageValidationError(f"Image must contain no more than {MAX_PIXELS:,} pixels.")
            probe.verify()
        with Image.open(io.BytesIO(data)) as decoded:
            decoded.load()
            image = ImageOps.exif_transpose(decoded).convert("RGB")
    except ImageValidationError:
        raise
    except (UnidentifiedImageError, OSError, ValueError, Image.DecompressionBombError) as exc:
        raise ImageValidationError("This image is corrupted or can't be read. Try another JPG or PNG.") from exc

    if not allow_large and max(image.size) > 10_000:
        raise ImageValidationError("Background images must be no larger than 10,000 pixels per side.")
    return image


def prepare_for_inference(image: Image.Image) -> Image.Image:
    """Resize using OpenCV while keeping the original aspect ratio."""
    width, height = image.size
    scale = min(1.0, INFERENCE_MAX_SIDE / max(width, height))
    if scale == 1.0:
        return image.copy()
    new_size = (max(1, round(width * scale)), max(1, round(height * scale)))
    rgb = np.asarray(image.convert("RGB"))
    resized = cv2.resize(rgb, new_size, interpolation=cv2.INTER_AREA)
    return Image.fromarray(resized, mode="RGB")


def composite_background(
    foreground: Image.Image,
    *,
    color: str | None = None,
    background: Image.Image | None = None,
) -> Image.Image:
    """Composite an RGBA foreground over a solid color or cover-fit image."""
    rgba = foreground.convert("RGBA")
    if background is not None:
        base = ImageOps.fit(background.convert("RGB"), rgba.size, method=Image.Resampling.LANCZOS)
        base = base.convert("RGBA")
    else:
        try:
            fill = color or "#FFFFFF"
            base = Image.new("RGBA", rgba.size, fill)
        except (ValueError, TypeError) as exc:
            raise ImageValidationError("Choose a valid background color.") from exc
    return Image.alpha_composite(base, rgba).convert("RGB")


def gradient_background(size: tuple[int, int], start: str, end: str, angle: int = 35) -> Image.Image:
    """Create a smooth two-color gradient at the target image size."""
    width, height = size
    first = np.array(Image.new("RGB", (1, 1), start), dtype=np.float32)[0, 0]
    last = np.array(Image.new("RGB", (1, 1), end), dtype=np.float32)[0, 0]
    yy, xx = np.mgrid[0:height, 0:width].astype(np.float32)
    radians = np.deg2rad(angle)
    projection = xx * np.cos(radians) + yy * np.sin(radians)
    low, high = float(projection.min()), float(projection.max())
    amount = (projection - low) / max(high - low, 1.0)
    pixels = first[None, None, :] * (1.0 - amount[:, :, None]) + last[None, None, :] * amount[:, :, None]
    return Image.fromarray(np.clip(pixels, 0, 255).astype(np.uint8), mode="RGB")
