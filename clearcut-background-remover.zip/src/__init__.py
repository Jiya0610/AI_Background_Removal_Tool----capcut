"""Core image-processing modules for the background removal app."""
