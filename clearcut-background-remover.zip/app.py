"""Streamlit interface for AI background removal."""

from __future__ import annotations

import hashlib
import base64
import io
import time

import numpy as np
import streamlit as st
import streamlit.components.v1 as components
from PIL import Image

from src.image_utils import ImageValidationError, composite_background, gradient_background, open_uploaded_image
from src.remover import RemovalError, apply_foreground_mask, generate_foreground_mask


st.set_page_config(page_title="Clearcut | AI Background Remover", page_icon="✂️", layout="wide")

st.markdown(
    """
    <style>
    :root { --ink:#17221f; --muted:#64716c; --green:#b9f36b; --paper:#f5f7f3; --line:#dce4dc; }
    .stApp { background:radial-gradient(ellipse at 50% 0%,#e8f1e5 0%,var(--paper) 52%); color:var(--ink); font-family:Inter,ui-sans-serif,system-ui,sans-serif; }
    header[data-testid="stHeader"] { background:rgba(245,247,243,.82); }
    .block-container { max-width:1240px; padding-top:2rem; padding-bottom:4rem; }
    h1,h2,h3 { font-family:Inter,ui-sans-serif,system-ui,sans-serif !important; letter-spacing:-.04em; }
    .hero { position:relative; overflow:hidden; background:linear-gradient(125deg,#17221f 0%,#203b30 100%); color:#f5f7f3; border-radius:24px; padding:38px 42px; margin:8px 0 30px; box-shadow:0 22px 54px #17221f20; }
    .hero:after { content:""; position:absolute; width:260px; height:260px; right:8%; top:-110px; border:1px solid #b9f36b38; border-radius:50%; box-shadow:0 0 0 28px #b9f36b0a,0 0 0 58px #b9f36b08; pointer-events:none; }
    .hero-kicker { color:var(--green); text-transform:uppercase; letter-spacing:.16em; font-size:12px; font-weight:700; }
    .hero h1 { color:#f5f7f3; font-size:clamp(34px,5vw,54px); line-height:1.05; margin:12px 0; }
    .hero p { color:#c4cec8; max-width:650px; font-size:16px; margin:0; }
    .eyebrow { color:#718078; font-size:12px; letter-spacing:.13em; font-weight:700; text-transform:uppercase; }
    [data-testid="stFileUploader"] { background:#fff !important; border:1px dashed #aebcaf; border-radius:18px; padding:12px; transition:border-color .2s,box-shadow .2s,transform .2s; }
    [data-testid="stFileUploader"]:hover { border-color:#5d893c; box-shadow:0 8px 24px #17221f0c; transform:translateY(-1px); }
    [data-testid="stFileUploader"] section { background:#fff !important; border:0 !important; }
    [data-testid="stFileUploader"] small,[data-testid="stFileUploader"] span,[data-testid="stFileUploader"] p { color:#56645c !important; }
    [data-testid="stFileUploader"] button { color:#fff !important; background:#17221f !important; border:1px solid #17221f !important; border-radius:9px !important; transition:transform .18s,background .18s,box-shadow .18s !important; }
    [data-testid="stFileUploader"] button:hover { background:#31543e !important; transform:translateY(-2px); box-shadow:0 6px 14px #17221f25; }
    [data-testid="stImage"] img { border-radius:14px; }
    div.stButton > button[kind="primary"] { background:#b9f36b; color:#17221f; border:1px solid #a9e45c; font-weight:750; border-radius:11px; box-shadow:0 5px 14px #8fbf5033; }
    div.stButton > button, .stDownloadButton button { border-radius:11px; font-weight:650; transition:transform .18s ease,box-shadow .18s ease,background .18s ease,color .18s ease,border-color .18s ease; }
    div.stButton > button:hover, .stDownloadButton button:hover { transform:translateY(-2px); box-shadow:0 8px 18px #17221f20; }
    div.stButton > button:active, .stDownloadButton button:active, [data-testid="stFileUploader"] button:active { transform:translateY(0) scale(.98); box-shadow:0 2px 6px #17221f1a; }
    div.stButton > button:focus-visible, .stDownloadButton button:focus-visible, [data-testid="stFileUploader"] button:focus-visible { outline:3px solid #82bd4c !important; outline-offset:3px; }
    .stDownloadButton button { background:#17221f; color:white; border:1px solid #17221f; font-weight:700; }
    .stDownloadButton button:hover { background:#31543e; color:white; border-color:#31543e; }
    div[data-testid="stRadio"] label { color:#34443a !important; }
    div[data-testid="stColorPicker"] label,div[data-testid="stSlider"] label,div[data-testid="stSelectbox"] label { color:#34443a !important; }
    .note { color:#64716c; font-size:13px; }
    @media (max-width:700px) { .block-container { padding:1rem 1rem 3rem; } .hero { padding:28px 24px; border-radius:18px; } .hero:after { right:-100px; } }
    </style>
    <div class="hero">
      <div class="hero-kicker">AI image studio · Private by design</div>
      <h1>Make your subject<br>the whole picture.</h1>
      <p>Remove a background in seconds, refine the edges, then place your subject on a new color or scene. Your image is processed by this app and isn't saved by it.</p>
    </div>
    """,
    unsafe_allow_html=True,
)


@st.cache_resource(show_spinner=False)
def get_model_session():
    """Load the lightweight U²-Net model once per app process."""
    from rembg import new_session

    return new_session("u2netp")


def png_bytes(image: Image.Image) -> bytes:
    out = io.BytesIO()
    image.save(out, format="PNG", optimize=True)
    return out.getvalue()


def jpeg_bytes(image: Image.Image) -> bytes:
    out = io.BytesIO()
    image.convert("RGB").save(out, format="JPEG", quality=94, optimize=True)
    return out.getvalue()


def comparison_slider(before: Image.Image, after: Image.Image) -> None:
    """Render a responsive, draggable before/after image comparison."""
    size = (900, 540)
    before = before.copy()
    after = after.copy()
    before.thumbnail(size, Image.Resampling.LANCZOS)
    after.thumbnail(size, Image.Resampling.LANCZOS)
    out_size = (min(before.width, after.width), min(before.height, after.height))
    before = before.resize(out_size, Image.Resampling.LANCZOS)
    after = after.resize(out_size, Image.Resampling.LANCZOS)

    def data_url(image: Image.Image) -> str:
        return "data:image/png;base64," + base64.b64encode(png_bytes(image)).decode("ascii")

    before_url, after_url = data_url(before), data_url(after)
    html = f"""
    <div class="compare" id="compare">
      <img class="photo" src="{before_url}" alt="Original image">
      <div class="after" id="after"><img class="photo" src="{after_url}" alt="Background removed"></div>
      <div class="line" id="line"><span>↔</span></div>
      <div class="tag left">BEFORE</div><div class="tag right">AFTER</div>
      <input aria-label="Compare before and after" type="range" min="0" max="100" value="50" id="range">
    </div>
    <style>
      *{{box-sizing:border-box}} body{{margin:0;font-family:Inter,system-ui,sans-serif}}
      .compare{{position:relative;width:100%;aspect-ratio:5/3;overflow:hidden;border-radius:16px;background:#e7ebe7;user-select:none}}
      .photo{{position:absolute;inset:0;width:100%;height:100%;object-fit:contain}}
      .after{{position:absolute;inset:0;width:50%;overflow:hidden;border-right:2px solid white}}
      .after .photo{{width:{out_size[0]}px;max-width:none;right:auto}}
      .line{{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:34px;height:34px;border-radius:50%;background:#b9f36b;color:#17221f;display:grid;place-items:center;font-weight:800;box-shadow:0 2px 12px #0004;pointer-events:none}}
      .tag{{position:absolute;top:12px;padding:6px 9px;border-radius:7px;background:#17221fdd;color:white;font-size:10px;letter-spacing:.12em;font-weight:700;pointer-events:none}}
      .left{{left:12px}}.right{{right:12px}}
      input{{position:absolute;inset:0;width:100%;height:100%;opacity:0;cursor:ew-resize;margin:0}}
    </style>
    <script>
      const range=document.getElementById('range'), after=document.getElementById('after'), line=document.getElementById('line'), img=after.querySelector('img');
      function sync(){{const p=range.value+'%';after.style.width=p;line.style.left=p;img.style.width=document.getElementById('compare').clientWidth+'px';}}
      range.addEventListener('input',sync);new ResizeObserver(sync).observe(document.getElementById('compare'));sync();
    </script>
    """
    components.html(html, height=400, scrolling=False)


def checkerboard(size: tuple[int, int]) -> Image.Image:
    width, height = size
    tile = 18
    y, x = np.indices((height, width))
    pattern = ((x // tile + y // tile) % 2) == 0
    pixels = np.where(pattern[:, :, None], [242, 244, 242], [218, 223, 219]).astype("uint8")
    return Image.fromarray(pixels, "RGB")


def get_state(key: str, default):
    if key not in st.session_state:
        st.session_state[key] = default
    return st.session_state[key]


st.markdown('<div class="eyebrow">01 / Add an image</div>', unsafe_allow_html=True)
uploader_key = get_state("uploader_key", 0)
uploaded = st.file_uploader(
    "Choose a photo",
    type=["jpg", "jpeg", "png"],
    help="JPG and PNG images up to 20 MB. Maximum dimensions: 12,000 × 12,000 pixels.",
    key=f"image_upload_{uploader_key}",
)

if uploaded is None:
    st.info("Upload a JPG or PNG to get started. For best results, use a clear image with a visible subject.")
    st.markdown("<p class='note'>Supported: JPG, JPEG, PNG · Maximum file size: 20 MB · Large images are scaled for inference and restored to their original dimensions.</p>", unsafe_allow_html=True)
    st.stop()

try:
    original = open_uploaded_image(uploaded)
except ImageValidationError as exc:
    st.error(str(exc))
    st.stop()

digest = hashlib.sha256(uploaded.getvalue()).hexdigest()
if st.session_state.get("image_digest") != digest:
    st.session_state.image_digest = digest
    st.session_state.pop("result_rgba", None)
    st.session_state.pop("foreground_mask", None)
    st.session_state.pop("processed_digest", None)

left, right = st.columns([1, 1.25], gap="large")
with left:
    st.image(original, caption=f"Original · {original.width:,} × {original.height:,} px", use_container_width=True)
    st.caption(f"{uploaded.name} · {len(uploaded.getvalue()) / (1024 * 1024):.1f} MB")
    run = st.button("Remove background", type="primary", use_container_width=True, key="remove_background")
    if run:
        try:
            with st.spinner("Finding the subject and refining its edges…"):
                started = time.perf_counter()
                mask = generate_foreground_mask(original, get_model_session())
                elapsed = time.perf_counter() - started
            st.session_state.foreground_mask = mask
            st.session_state.processed_digest = digest
            st.session_state.processing_seconds = elapsed
        except ImportError:
            st.error("The AI dependencies aren't installed. Run `pip install -r requirements.txt`, then restart the app.")
        except RemovalError as exc:
            st.error(str(exc))
        except Exception as exc:  # Keep model/runtime failures inside the UI.
            st.error(f"The model couldn't process this image. Check your connection for the first model download, then try again. Details: {exc}")

with right:
    st.markdown('<div class="eyebrow">02 / Preview and customize</div>', unsafe_allow_html=True)
    mask = st.session_state.get("foreground_mask") if st.session_state.get("processed_digest") == digest else None
    if mask is None:
        st.markdown("### Your cutout will appear here")
        st.markdown("The subject mask is generated by a pretrained AI model. Processing time depends on your image size and device.")
    else:
        st.success(f"Background removed in {st.session_state.processing_seconds:.1f} seconds")
        softness = st.slider("Edge softness", 0.0, 2.5, 0.7, 0.1, help="Smooths jagged mask boundaries. Higher values soften fine details more.", key="edge_softness")
        rgba = apply_foreground_mask(original, mask, softness)
        with st.expander("Inspect AI mask"):
            st.caption("White pixels are retained as the subject; black pixels are removed as background.")
            st.image(mask, caption="Foreground mask", use_container_width=True)

        st.markdown("#### Choose a background")
        mode = st.radio("Background", ["Transparent", "Solid color", "Gradient", "Image"], horizontal=True, label_visibility="collapsed", key="background_mode")
        composed = rgba
        if mode == "Solid color":
            preset = st.selectbox("Color preset", ["Soft white", "Ink black", "Warm gray", "Custom"], key="color_preset")
            preset_colors = {"Soft white": "#F5F7F3", "Ink black": "#17221F", "Warm gray": "#D8D0C4"}
            color = st.color_picker("Background color", "#F5F7F3", key="background_color") if preset == "Custom" else preset_colors[preset]
            composed = composite_background(rgba, color=color)
        elif mode == "Gradient":
            g1, g2, g3 = st.columns(3)
            start = g1.color_picker("Gradient start", "#B9F36B", key="gradient_start")
            end = g2.color_picker("Gradient end", "#D9F3FF", key="gradient_end")
            angle = g3.slider("Angle", 0, 180, 35, key="gradient_angle")
            background = gradient_background(rgba.size, start, end, angle)
            composed = composite_background(rgba, background=background)
        elif mode == "Image":
            bg_upload = st.file_uploader("Choose a background image", type=["jpg", "jpeg", "png"], key="background_upload")
            if bg_upload is not None:
                try:
                    bg = open_uploaded_image(bg_upload, allow_large=False)
                    composed = composite_background(rgba, background=bg)
                except ImageValidationError as exc:
                    st.error(f"Background image: {exc}")
            else:
                st.caption("Upload a JPG or PNG. It will be resized to fit the subject image.")

        if mode == "Transparent":
            preview_background = checkerboard(rgba.size)
            comparison_after = composite_background(rgba, background=preview_background)
            jpeg_output = composite_background(rgba, color="#FFFFFF")
            png_output = rgba
        else:
            comparison_after = composed
            jpeg_output = composed
            png_output = composed
        st.markdown("#### Drag to compare")
        comparison_slider(original, comparison_after)
        transparent_data = png_bytes(rgba)
        dl1, dl2, dl3 = st.columns(3)
        dl1.download_button("Transparent PNG", transparent_data, file_name="background-removed.png", mime="image/png", use_container_width=True)
        dl2.download_button("Final PNG", png_bytes(png_output), file_name="background-customized.png", mime="image/png", use_container_width=True)
        dl3.download_button("Final JPEG", jpeg_bytes(jpeg_output), file_name="background-customized.jpg", mime="image/jpeg", use_container_width=True)

st.divider()
with st.expander("How it works and image limits"):
    st.markdown(
        """
        Images are checked for format, size, readability, and pixel dimensions before processing. OpenCV scales oversized images for model inference while preserving the aspect ratio; the resulting mask is then mapped back onto the original image. The lightweight U²-NetP model runs through `rembg`. On first use, it may need to download model weights, so an internet connection is required. The app doesn't write uploaded images or results to disk.

        **Limits:** JPG/PNG only · 20 MB maximum upload · 12,000 px per side · 40 million pixels maximum. Inference is capped at a 2,000 px longest side to limit memory use.
        """
    )

if st.button("Start over / upload another image", key="reset_app"):
    st.session_state.uploader_key = uploader_key + 1
    for key in ("image_digest", "result_rgba", "foreground_mask", "processed_digest", "processing_seconds", "background_upload"):
        st.session_state.pop(key, None)
    st.rerun()
